import pytest
from app import app, db, User, Article
import jwt

def get_token(client, username):
    client.post('/register', json={'username': username})
    rv = client.post('/login', json={'username': username})
    return rv.get_json()['token']

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SECRET_KEY'] = 'test-secret'
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client
        with app.app_context():
            db.drop_all()

def auth_headers(token):
    return {'Authorization': f'Bearer {token}'}

def test_register_and_login(client):
    rv = client.post('/register', json={'username': 'testuser'})
    assert rv.status_code == 200
    rv = client.post('/login', json={'username': 'testuser'})
    assert rv.status_code == 200
    assert 'token' in rv.get_json()

def test_create_and_get_article(client):
    token = get_token(client, 'testuser')
    rv = client.post('/articles', json={'title': 'Test', 'content': 'Content'}, headers=auth_headers(token))
    assert rv.status_code == 201
    data = rv.get_json()
    article_id = data['id']
    rv = client.get(f'/articles/{article_id}', headers=auth_headers(token))
    assert rv.status_code == 200
    assert rv.get_json()['title'] == 'Test'

def test_update_article(client):
    token = get_token(client, 'testuser')
    rv = client.post('/articles', json={'title': 'Old', 'content': 'Old'}, headers=auth_headers(token))
    article_id = rv.get_json()['id']
    rv = client.put(f'/articles/{article_id}', json={'title': 'New'}, headers=auth_headers(token))
    assert rv.status_code == 200
    assert rv.get_json()['title'] == 'New'

def test_delete_article(client):
    token = get_token(client, 'testuser')
    rv = client.post('/articles', json={'title': 'ToDelete', 'content': 'X'}, headers=auth_headers(token))
    article_id = rv.get_json()['id']
    rv = client.delete(f'/articles/{article_id}', headers=auth_headers(token))
    assert rv.status_code == 204
    rv = client.get(f'/articles/{article_id}', headers=auth_headers(token))
    assert rv.status_code == 404

def test_list_articles_and_pagination(client):
    token = get_token(client, 'testuser')
    for i in range(15):
        client.post('/articles', json={'title': f'A{i}', 'content': 'A'}, headers=auth_headers(token))
    rv = client.get('/articles?page=1&limit=10', headers=auth_headers(token))
    assert rv.status_code == 200
    data = rv.get_json()
    assert len(data['articles']) == 10
    assert data['total'] == 15
    assert data['page'] == 1
    assert data['limit'] == 10
    rv = client.get('/articles?page=2&limit=10', headers=auth_headers(token))
    data = rv.get_json()
    assert len(data['articles']) == 5

def test_recently_viewed(client):
    token = get_token(client, 'testuser')
    ids = []
    for i in range(6):
        rv = client.post('/articles', json={'title': f'T{i}', 'content': 'C'}, headers=auth_headers(token))
        ids.append(rv.get_json()['id'])
    for aid in ids:
        client.get(f'/articles/{aid}', headers=auth_headers(token))
    rv = client.get('/recently_viewed', headers=auth_headers(token))
    assert rv.status_code == 200
    assert len(rv.get_json()) == 5 